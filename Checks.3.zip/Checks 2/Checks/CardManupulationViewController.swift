
import UIKit

class CardManupulationViewController: UIViewController {

    //for picker view
    let RecurringTypes: [String] = ["daily", "weekly", "biweekly", "monthly", "bimonthly", "quarterly", "semiannually", "annually"]

    @IBOutlet weak var segmentController: UISegmentedControl!
    //Labels...
    
    
    @IBOutlet weak var saleLbl: UILabel!
    @IBOutlet weak var cardNumberLbl: UILabel!
    @IBOutlet weak var cardExpLbl: UILabel!
    @IBOutlet weak var cvvLbl: UILabel!
    @IBOutlet weak var orderIdLbl: UILabel!
    @IBOutlet weak var ownerNameLbl: UILabel!
    @IBOutlet weak var recurringNumberLbl: UILabel!
    @IBOutlet weak var startDateLbl: UILabel!
    @IBOutlet weak var recurringTypeLbl: UILabel!
    @IBOutlet weak var endDateLbl: UILabel!
    
    //fieldz...
    
    @IBOutlet weak var saleTxt: UITextField!
    @IBOutlet weak var cardNumberTxt: UITextField!
    @IBOutlet weak var cardExpTxt: UITextField!
    @IBOutlet weak var cvvTxt: UITextField!
    @IBOutlet weak var orderIdTxt: UITextField!
    @IBOutlet weak var ownerNameTxt: UITextField!
    @IBOutlet weak var recurringNumberTxt: UITextField!
    @IBOutlet weak var startDateTxt: UITextField!
    @IBOutlet weak var recurringTypeTxt: UITextField!
    //@IBOutlet weak var recurringTypeTxt: UITextField!
    //@IBOutlet weak var recurringTypePopOver: UIButton!
    @IBOutlet weak var endDateTxt: UITextField!
    
    //views.....
    
    @IBOutlet weak var saleView: UIView!
    @IBOutlet weak var cardNumberView: UIView!
    @IBOutlet weak var cardExpView: UIView!
    @IBOutlet weak var cvvView: UIView!
    @IBOutlet weak var orderIdView: UIView!
    @IBOutlet weak var ownerNameView: UIView!
    @IBOutlet weak var recurringNumberView: UIView!
    @IBOutlet weak var startDateView: UIView!
    @IBOutlet weak var recurringTypeView: UIView!
    @IBOutlet weak var endDateView: UIView!
    
    //Alerts...
    func showAlert(){
        let alert = UIAlertController (title: "Alert", message: "All Fields are necessery", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
        
        //UIApplication.sharedApplication().delegate?.window!?.rootViewController?.presentViewController(alert, animated: true, completion: nil)
        self.presentViewController(alert, animated: true, completion:  nil)
    }
    //var picker : UIPickerView? = UIPickerView()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let picker = UIPickerView()
        picker.delegate = self
        //picker!.dataSource = self
        recurringTypeTxt.inputView = picker
        print("hello from changing")
        
        switch segmentController.selectedSegmentIndex{
        case 0:
            self.view.makeToast("Sale")
            recurringNumberLbl.hidden = true
            recurringNumberTxt.hidden = true
            recurringNumberView.hidden = true
            
            startDateLbl.hidden = true
            startDateTxt.hidden = true
            startDateView.hidden = true
            
            recurringTypeLbl.hidden = true
            recurringTypeTxt.hidden = true
            recurringTypeView.hidden = true
            
            endDateLbl.hidden = true
            endDateTxt.hidden = true
            endDateView.hidden = true
        case 1:
            self.view.makeToast("Void")
        case 2:
            self.view.makeToast("PreAuth")
        case 3:
            self.view.makeToast("Recurring")
        default:
            self.view.makeToast("Default")
        }
        
        
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "bg.png")!)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    //functions for validations...
    @IBAction func onSubmit(sender: AnyObject) {
        
        // for segment 0 and 2
        
        if(saleTxt.text == "0.00" && segmentController.selectedSegmentIndex == 0 ){
            showAlert()
        }
        else if(cardNumberTxt.text == "" && segmentController.selectedSegmentIndex == 0 ){
            showAlert()
        }
        else if(cardExpTxt.text == "" && segmentController.selectedSegmentIndex == 0 ){
            showAlert()
        }
        else if(orderIdTxt.text == "" && segmentController.selectedSegmentIndex == 0 ){
            showAlert()
        }
        else if(ownerNameTxt.text == "" && segmentController.selectedSegmentIndex == 0 ){
            showAlert()
        }
        
        // for segment 1
        
        if(saleTxt.text == "" && segmentController.selectedSegmentIndex == 1){
            showAlert()
        }
        if(cardNumberTxt.text == "" && segmentController.selectedSegmentIndex == 1){
            showAlert()
        }
        
        
        // for segment 2
        
        if(saleTxt.text == "0.00" &&  segmentController.selectedSegmentIndex == 2){
            showAlert()
        }
        else if(cardNumberTxt.text == "" && segmentController.selectedSegmentIndex == 2){
            showAlert()
        }
        else if(cardExpTxt.text == "" && segmentController.selectedSegmentIndex == 2){
            showAlert()
        }
        else if(orderIdTxt.text == "" && segmentController.selectedSegmentIndex == 2){
            showAlert()
        }
        else if(ownerNameTxt.text == "" && segmentController.selectedSegmentIndex == 2){
            showAlert()
        }
        
        // for segment 3
        
        if(saleTxt.text == "0.00" &&  segmentController.selectedSegmentIndex == 3){
            showAlert()
        }
        else if(cardNumberTxt.text == "" && segmentController.selectedSegmentIndex == 3){
            showAlert()
        }
        else if(cardExpTxt.text == "" && segmentController.selectedSegmentIndex == 3){
            showAlert()
        }
        else if(orderIdTxt.text == "" && segmentController.selectedSegmentIndex == 3){
            showAlert()
        }
        else if(ownerNameTxt.text == "" && segmentController.selectedSegmentIndex == 3){
            showAlert()
        }
        else if(recurringNumberTxt.text == "" && segmentController.selectedSegmentIndex == 3){
            showAlert()
        }
        else if(startDateTxt.text ==  "" && segmentController.selectedSegmentIndex == 3){
            showAlert()
        }
        else if(recurringTypeTxt.text == "" && segmentController.selectedSegmentIndex == 3){
            showAlert()
        }
        else if(endDateTxt.text == "" && segmentController.selectedSegmentIndex == 3){
            showAlert()
        }
    }
    
    @IBAction func onIndexChangedOfSegment(sender: AnyObject) {
        switch segmentController.selectedSegmentIndex{
        case 0:
            self.view.makeToast("Sale")
            
            saleLbl.text = "Sale Amount $"
            saleTxt.text = "0.00"
            
            cardNumberLbl.text = "Cradit Card Number"
            cardNumberTxt.placeholder = "cradit card number"
            
            saleView.hidden = false
            saleTxt.hidden = false
            saleLbl.hidden = false
            
            cardNumberTxt.hidden = false
            cardNumberLbl.hidden = false
            cardNumberView.hidden = false
            
            
            cardExpLbl.hidden = false
            cardExpTxt.hidden = false
            cardExpView.hidden = false
            
            cvvLbl.hidden = false
            cvvTxt.hidden = false
            cvvView.hidden = false
            
            orderIdLbl.hidden = false
            orderIdTxt.hidden = false
            orderIdView.hidden = false
            
            ownerNameView.hidden = false
            ownerNameLbl.hidden = false
            ownerNameTxt.hidden = false
            
            ownerNameLbl.hidden = false
            ownerNameTxt.hidden = false
            
            recurringNumberLbl.hidden = true
            recurringNumberTxt.hidden = true
            recurringNumberView.hidden = true
            
            startDateLbl.hidden = true
            startDateTxt.hidden = true
            startDateView.hidden = true
            
            recurringTypeLbl.hidden = true
            recurringTypeTxt.hidden = true
            recurringTypeView.hidden = true
            
            endDateLbl.hidden = true
            endDateTxt.hidden = true
            endDateView.hidden = true
        case 1:
            self.view.makeToast("Void")
            
            saleLbl.text = "Owner Name"
            saleTxt.text = ""
            saleTxt.placeholder = "owner name"
            
            cardNumberLbl.text = "Reference Number/Transcation Number"
            cardNumberTxt.placeholder = "reference number"
            
            cardExpLbl.hidden = true
            cardExpTxt.hidden = true
            cardExpView.hidden = true
            
            cvvLbl.hidden = true
            cvvTxt.hidden = true
            cvvView.hidden = true
            
            orderIdLbl.hidden = true
            orderIdTxt.hidden = true
            orderIdView.hidden = true
            
            ownerNameView.hidden = true
            ownerNameLbl.hidden = true
            ownerNameTxt.hidden = true
            
            ownerNameLbl.hidden = true
            ownerNameTxt.hidden = true
            ownerNameView.hidden = true
            
            recurringNumberLbl.hidden = true
            recurringNumberTxt.hidden = true
            recurringNumberView.hidden = true
            
            startDateLbl.hidden = true
            startDateTxt.hidden = true
            startDateView.hidden = true
            
            recurringTypeLbl.hidden = true
            recurringTypeTxt.hidden = true
            recurringTypeView.hidden = true
            
            endDateLbl.hidden = true
            endDateTxt.hidden = true
            endDateView.hidden = true
            
        case 2:
            self.view.makeToast("PreAuth")
            
            saleLbl.text = "Sale Amount $"
            saleTxt.text = "0.00"
            
            cardNumberLbl.text = "Cradit Card Number"
            cardNumberTxt.placeholder = "cradit card number"
            
            saleView.hidden = false
            saleTxt.hidden = false
            saleLbl.hidden = false
            
            cardNumberTxt.hidden = false
            cardNumberLbl.hidden = false
            cardNumberView.hidden = false
            
            
            cardExpLbl.hidden = false
            cardExpTxt.hidden = false
            cardExpView.hidden = false
            
            cvvLbl.hidden = false
            cvvTxt.hidden = false
            cvvView.hidden = false
            
            orderIdLbl.hidden = false
            orderIdTxt.hidden = false
            orderIdView.hidden = false
            
            ownerNameView.hidden = false
            ownerNameLbl.hidden = false
            ownerNameTxt.hidden = false
            
            ownerNameLbl.hidden = false
            ownerNameTxt.hidden = false
            
            recurringNumberLbl.hidden = true
            recurringNumberTxt.hidden = true
            recurringNumberView.hidden = true
            
            startDateLbl.hidden = true
            startDateTxt.hidden = true
            startDateView.hidden = true
            
            recurringTypeLbl.hidden = true
            recurringTypeTxt.hidden = true
            recurringTypeView.hidden = true
            
            endDateLbl.hidden = true
            endDateTxt.hidden = true
            endDateView.hidden = true
            
        case 3:
            self.view.makeToast("Recurring")
            
            saleLbl.text = "Sale Amount $"
            saleTxt.text = "0.00"
            
            cardNumberLbl.text = "Cradit Card Number"
            cardNumberTxt.placeholder = "cradit card number"
            
            saleView.hidden = false
            saleTxt.hidden = false
            saleLbl.hidden = false
            
            cardNumberTxt.hidden = false
            cardNumberLbl.hidden = false
            cardNumberView.hidden = false
            
            
            cardExpLbl.hidden = false
            cardExpTxt.hidden = false
            cardExpView.hidden = false
            
            cvvLbl.hidden = false
            cvvTxt.hidden = false
            cvvView.hidden = false
            
            orderIdLbl.hidden = false
            orderIdTxt.hidden = false
            orderIdView.hidden = false
            
            ownerNameView.hidden = false
            ownerNameLbl.hidden = false
            ownerNameTxt.hidden = false
            
            ownerNameLbl.hidden = false
            ownerNameTxt.hidden = false
            
            recurringNumberLbl.hidden = true
            recurringNumberTxt.hidden = true
            recurringNumberView.hidden = true
            
            startDateLbl.hidden = true
            startDateTxt.hidden = true
            startDateView.hidden = true
            
            recurringTypeLbl.hidden = true
            recurringTypeTxt.hidden = true
            recurringTypeView.hidden = true
            
            endDateLbl.hidden = true
            endDateTxt.hidden = true
            endDateView.hidden = true
            
            recurringNumberLbl.hidden = false
            recurringNumberTxt.hidden = false
            recurringNumberView.hidden = false
            
            startDateLbl.hidden = false
            startDateTxt.hidden = false
            startDateView.hidden = false
            
            recurringTypeLbl.hidden = false
            recurringTypeTxt.hidden = false
            recurringTypeView.hidden = false
            
            endDateLbl.hidden = false
            endDateTxt.hidden = false
            endDateView.hidden = false
            
        default:
            self.view.makeToast("Default")
        }
    }
}
extension CardManupulationViewController: UIPickerViewDataSource {
    
    func numberOfComponentsInPickerView(colorPicker: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 6
    }
}

extension CardManupulationViewController: UIPickerViewDelegate {
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        var RecurringTypes: [String] = ["daily", "weekly", "biweekly", "monthly", "bimonthly", "quarterly", "semiannually", "annually"]
        return RecurringTypes[row]
    }
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        recurringTypeTxt.text = RecurringTypes[row]
        recurringTypeTxt.resignFirstResponder()
    }
    
}