
import UIKit
import QuartzCore

class ViewController: UIViewController {

    @IBOutlet weak var Scroller: UIScrollView!
    let RecurringTypes: [String] = ["daily", "weekly", "biweekly", "monthly", "bimonthly", "quarterly", "semiannually", "annually"]
    // Labels
    
    @IBOutlet weak var SaleAmount: UILabel!
    @IBOutlet weak var OrderId: UILabel!
    @IBOutlet weak var RoutingNumber: UILabel!
    @IBOutlet weak var DirectDepositAccount: UILabel!
    @IBOutlet weak var CheckNumber: UILabel!
    @IBOutlet weak var AccountType: UILabel!
    
    @IBOutlet weak var OwnerName: UILabel!
    
    // TextFields
    
    
    @IBOutlet weak var SaleAmountTextField: UITextField!
    @IBOutlet weak var OrderIdTextField: UITextField!
    @IBOutlet weak var RoutingNumTextField: UITextField!
    @IBOutlet weak var DirectDepAccTextField: UITextField!
    @IBOutlet weak var RecurringType: UILabel!
    @IBOutlet weak var EndDate: UILabel!
    @IBOutlet weak var RecurringNumber: UILabel!
    @IBOutlet weak var StartDate: UILabel!
    @IBOutlet weak var CheckNumTextField: UITextField!
    @IBOutlet weak var OwnerNameTextField: UITextField!
    
    @IBOutlet weak var SegmentControl: UISegmentedControl!
    
    //ChkBoxButtons and LAbels
    
    @IBOutlet weak var Button1Checking: checkBox!
    @IBOutlet weak var Button2Saving: checkBox!
    @IBOutlet weak var Checking: UILabel!
    @IBOutlet weak var RecurringNumTextField: UITextField!
    @IBOutlet weak var Saving: UILabel!
    @IBOutlet weak var RecurringStartDateTextField: UITextField!
    
    // RectangularViews
    @IBOutlet weak var RecurringEndDateTextField: UITextField!
    @IBOutlet weak var tableViewTextField: UITextField!
    
    @IBOutlet weak var SaleView: UIView!
    @IBOutlet weak var OrderIdView: UIView!
    @IBOutlet weak var RoutingNumView: UIView!
    @IBOutlet weak var DirectDepAccountView: UIView!
    @IBOutlet weak var CheckNumView: UIView!
    @IBOutlet weak var lastLineView: UIView!
    @IBOutlet weak var RecurringEndDateView: UIView!
    @IBOutlet weak var RecurringTypeView: UIView!
    @IBOutlet weak var RecurringStartDateView: UIView!
    @IBOutlet weak var RecurringNumView: UIView!
    
    @IBOutlet weak var imageViewChecking: checkBox!
    @IBOutlet weak var imageViewSaving: checkBox!
    
    var CheckingOrSaving = 1
    let checkedImage = UIImage(named: "radiobutton_checked.png") as UIImage?
    let unCheckedImage = UIImage(named: "radiobutton_unchecked.png") as UIImage?
    
    @IBAction func checkingClicked(sender: AnyObject) {
        if CheckingOrSaving == 1 {
            imageViewSaving.setImage(unCheckedImage, forState: .Normal)
            imageViewChecking.setImage(checkedImage, forState: .Normal)
        }
    }
    @IBAction func savingClicked(sender: AnyObject) {
        if CheckingOrSaving == 2 {
            imageViewSaving.setImage(checkedImage, forState: .Normal)
            imageViewChecking.setImage(unCheckedImage, forState: .Normal)
        }
    }
    
    
    @IBAction func SelectedSegment(sender: AnyObject) {
        
        if(SegmentControl.selectedSegmentIndex == 0)
        {
            self.view.makeToast("Sale")
            SaleAmount.text = "Sale Amount $"
            OrderId.text = "Order Id"
            SaleAmountTextField.text = "0.00"
            OrderIdTextField.placeholder = "order id"
            
            //unhide label objects
            
            RoutingNumber.hidden = false
            DirectDepositAccount.hidden = false
            CheckNumber.hidden = false
            AccountType.hidden = false
            OwnerName.hidden = false
            
            //Unhiding textField Objects
            
            RoutingNumTextField.hidden = false
            DirectDepAccTextField.hidden = false
            CheckNumTextField.hidden = false
            OwnerNameTextField.hidden = false
            
            //Unhiding CheckBox Objects
            
            Button1Checking.hidden = false
            Button2Saving.hidden = false
            Checking.hidden = false
            Saving.hidden = false
            
            //Unhiding Rectangular Views
            
            RoutingNumView.hidden = false
            DirectDepAccountView.hidden = false
            CheckNumView.hidden = false
            lastLineView.hidden = false
            
            // hiding objects of Sale PArt
            
            RecurringNumber.hidden = true
            RecurringNumTextField.hidden = true
            RecurringNumView.hidden = true
            StartDate.hidden = true
            RecurringStartDateTextField.hidden = true
            RecurringStartDateView.hidden = true
            RecurringType.hidden = true
            tableViewTextField.hidden = true
            EndDate.hidden = true
            RecurringEndDateTextField.hidden = true
            RecurringEndDateView.hidden = true
            
            
            
            
            
        }
        if(SegmentControl.selectedSegmentIndex == 1)
        {
            self.view.makeToast("Void")
            SaleAmount.text = "Check (optional)"
            SaleAmountTextField.text = ""
            SaleAmountTextField.placeholder = "Check Number"
            OrderId.text = "Reference Number/Transaction Number"
            OrderIdTextField.placeholder = "reference number"
            
            //hiding label objects
            
            RoutingNumber.hidden = true
            DirectDepositAccount.hidden = true
            CheckNumber.hidden = true
            AccountType.hidden = true
            OwnerName.hidden = true
            
            //hiding textField Objects
            
            RoutingNumTextField.hidden = true
            DirectDepAccTextField.hidden = true
            CheckNumTextField.hidden = true
            OwnerNameTextField.hidden = true
            
            // Hiding CheckBox Objects
            
            Button1Checking.hidden = true
            Button2Saving.hidden = true
            Checking.hidden = true
            Saving.hidden = true
            
            // Hiding Rectangular Views
            
            RoutingNumView.hidden = true
            DirectDepAccountView.hidden = true
            CheckNumView.hidden = true
            lastLineView.hidden = true
            
            
            // hiding objects
            
            RecurringNumber.hidden = true
            RecurringNumTextField.hidden = true
            RecurringNumView.hidden = true
            StartDate.hidden = true
            RecurringStartDateTextField.hidden = true
            RecurringStartDateView.hidden = true
            RecurringType.hidden = true
            tableViewTextField.hidden = true
            EndDate.hidden = true
            RecurringEndDateTextField.hidden = true
            RecurringEndDateView.hidden = true
            
            
        }
        if(SegmentControl.selectedSegmentIndex == 2)
        {
            self.view.makeToast("Recurring")
            
            SaleAmount.text = "Sale Amount $"
            OrderId.text = "Order Id"
            SaleAmountTextField.text = "0.00"
            OrderIdTextField.placeholder = "order id"
            
            //unhide label objects
            
            RoutingNumber.hidden = false
            DirectDepositAccount.hidden = false
            CheckNumber.hidden = false
            AccountType.hidden = false
            OwnerName.hidden = false
            
            //Unhiding textField Objects
            
            RoutingNumTextField.hidden = false
            DirectDepAccTextField.hidden = false
            CheckNumTextField.hidden = false
            OwnerNameTextField.hidden = false
            
            //Unhiding CheckBox Objects
            
            Button1Checking.hidden = false
            Button2Saving.hidden = false
            Checking.hidden = false
            Saving.hidden = false
            
            //Unhiding Rectangular Views
            
            RoutingNumView.hidden = false
            DirectDepAccountView.hidden = false
            CheckNumView.hidden = false
            lastLineView.hidden = false
            
            //unhiding objects
            
            RecurringNumber.hidden = false
            RecurringNumTextField.hidden = false
            RecurringNumView.hidden = false
            StartDate.hidden = false
            RecurringStartDateTextField.hidden = false
            RecurringStartDateView.hidden = false
            RecurringType.hidden = false
            tableViewTextField.hidden = false
            EndDate.hidden = false
            RecurringEndDateTextField.hidden = false
            RecurringEndDateView.hidden = false
            

            
        }
    }
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor (patternImage: UIImage(named: "bg.png")!)
        let picker = UIPickerView()
        picker.delegate = self
        //picker.dataSource = self
        tableViewTextField.inputView = picker
        
        if(SegmentControl.selectedSegmentIndex == 0)
        {
            self.view.makeToast("Sale")
            // hiding objects of Sale PArt
            
            RecurringNumber.hidden = true
            RecurringNumTextField.hidden = true
            RecurringNumView.hidden = true
            StartDate.hidden = true
            RecurringStartDateTextField.hidden = true
            RecurringStartDateView.hidden = true
            RecurringType.hidden = true
            tableViewTextField.hidden = true
            EndDate.hidden = true
            RecurringEndDateTextField.hidden = true
            RecurringEndDateView.hidden = true
        }
        if(SegmentControl.selectedSegmentIndex == 1)
        {
            self.view.makeToast("void")
        }
        if(SegmentControl.selectedSegmentIndex == 2)
        {
            self.view.makeToast("recurring")
        }
        
        self.view.makeToast("Sale")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
extension ViewController: UIPickerViewDataSource {
    
    func numberOfComponentsInPickerView(colorPicker: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 6
    }
}

extension ViewController: UIPickerViewDelegate {
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        var RecurringTypes: [String] = ["daily", "weekly", "biweekly", "monthly", "bimonthly", "quarterly", "semiannually", "annually"]
        return RecurringTypes[row]
    }
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        tableViewTextField.text = RecurringTypes[row]
        tableViewTextField.resignFirstResponder()
    }
    
}
