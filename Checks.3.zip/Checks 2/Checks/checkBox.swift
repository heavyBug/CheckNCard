

import UIKit

class checkBox: UIButton {
    
    
    //images
    
    let checkedImage = UIImage(named: "radiobutton_checked.png") as UIImage?
    
    let unCheckedImage = UIImage(named: "radiobutton_unchecked.png") as UIImage?
    
    //bool property
    
    var isChecked : Bool = false{
        
        didSet{
            if isChecked == true
            {
                self.setImage(checkedImage, forState: .Normal)
            }
            else{
                
                self.setImage(unCheckedImage, forState: .Normal)
            }
        }
    }
    
    override func awakeFromNib() {
        self.addTarget(self, action: "buttonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
    }
    
    func buttonClicked(sender : UIButton)
    {
        if sender == self{
            if isChecked == true{
                isChecked = false
            }else{
                isChecked = true
            }
        }
    }



    

}