//
//  FinalOkViewController.swift
//  Checks
//
//  Created by Ali Asad on 18/02/2016.
//  Copyright © 2016 Saba Majeed. All rights reserved.
//

import UIKit

class FinalOkViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    var image : UIImage = UIImage()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor (patternImage: UIImage(named: "bg.png")!)
        imageView.image = image
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
