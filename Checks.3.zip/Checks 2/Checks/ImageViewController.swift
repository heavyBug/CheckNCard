//
//  ImageViewController.swift
//  Checks
//
//  Created by Ali Asad Saeed on 14/01/2016.
//  Copyright © 2016 Saba Majeed. All rights reserved.
//

import UIKit

class ImageViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: Selector("tapAction:"))
        
        self.imageView.userInteractionEnabled = true
        self.imageView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @IBAction func Cancel(sender: AnyObject) {
        exit(0)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tapAction(sender: UITapGestureRecognizer) {
        
        let touchPoint = sender.locationInView(self.imageView) // Change to whatever view you want the point for
        print(touchPoint)
    }
}
