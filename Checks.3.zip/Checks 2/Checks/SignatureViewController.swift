//
//  SignatureViewController.swift
//  Checks
//
//  Created by Ali Asad on 18/02/2016.
//  Copyright © 2016 Saba Majeed. All rights reserved.
//

import UIKit

class SignatureViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor (patternImage: UIImage(named: "bg.png")!)
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var signatureView: YPDrawSignatureView!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let handler = segue.destinationViewController as! FinalOkViewController
        handler.image  = signatureView.getSignature()
    }
}